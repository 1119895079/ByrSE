package com.example.byrsearch.dao;

import com.example.byrsearch.domain.search_result;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @packagename com.example.byrsearch.Dao
 * @Description
 * @Date 2022/10/31 20:01
 */
@Mapper
public interface ResultDao {
    List<search_result> selectAll();
}
