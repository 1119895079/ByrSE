package com.example.byrsearch.domain;

import java.sql.Timestamp;

/**
 * @packagename com.example.byrsearch.domain
 * @Description
 * @Date 2022/10/31 19:44
 */
public class search_result {
    private Integer index;
    private String url;
    private String title;
    private Timestamp date;
    private String description;

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Timestamp getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "search_result{" +
                "index=" + index +
                ", url='" + url + '\'' +
                ", title='" + title + '\'' +
                ", date=" + date +
                ", description='" + description + '\'' +
                '}';
    }
}
