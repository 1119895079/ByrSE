package com.example.byrsearch.service;

import com.example.byrsearch.dao.ResultDao;
import com.example.byrsearch.domain.search_result;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @packagename com.example.byrsearch.service
 * @Description
 * @Date 2022/10/31 20:39
 */
public interface ResultService {
    List<search_result> queryResult();

}
