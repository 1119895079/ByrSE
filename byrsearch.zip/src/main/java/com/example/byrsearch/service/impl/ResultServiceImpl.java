package com.example.byrsearch.service.impl;

import com.example.byrsearch.dao.ResultDao;
import com.example.byrsearch.domain.search_result;
import com.example.byrsearch.service.ResultService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @packagename com.example.byrsearch.service
 * @Description
 * @Date 2022/10/31 20:41
 */
public class ResultServiceImpl implements ResultService {
    @Autowired
    private ResultDao resultDao;


    @Override
    public List<search_result> queryResult() {
        return resultDao.selectAll();
    }
}
