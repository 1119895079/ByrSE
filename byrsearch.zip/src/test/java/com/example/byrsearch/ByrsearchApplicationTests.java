package com.example.byrsearch;

import com.example.byrsearch.dao.ResultDao;
import com.example.byrsearch.domain.search_result;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class ByrsearchApplicationTests {

    @Autowired
    private ResultDao resultDao;
    @Test
    void contextLoads() {
        List<search_result> search_results = resultDao.selectAll();
        System.out.println(search_results);
    }

}
